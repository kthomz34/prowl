var constants = Object.freeze({
  appId: 'amzn1.ask.skill.b5cffee7-c568-4826-a2be-489902761c92',
});

module.exports = constants;
