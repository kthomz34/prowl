var alexaMeetups = [
  {
    "city": "Appleton",
    "meetupURL": "Appleton-Amazon-Alexa-Meetup",
  },
  {
    "city": "Berlin",
    "meetupURL": "Berlin-Voice-Interfaces",
  },
  {
    "city": "Boston",
    "meetupURL": "Boston-Alexa-Developers",
  },
  {
    "city": "Dublin",
    "meetupURL": "alexadevs",
  },
  {
    "city": "Grand Rapids",
    "meetupURL": "Grand-Rapids-Alexa-Meetup",
  },
  {
    "city": "Indianapolis",
    "meetupURL": "Indianapolis-Amazon-Alexa",
  },
  {
    "city": "London",
    "meetupURL": "London-Alexa-Devs",
  },
  {
    "city": "Los Angeles",
    "meetupURL": "Los-Angeles-Amazon-Echo-Developer-Meetup",
  },
  {
    "city": "New York",
    "meetupURL": "NYC-Amazon-Alexa-Meetup",
  },
  {
    "city": "Paris",
    "meetupURL": "Voice-Interfaces-Paris",
  },
  {
    "city": "Philadelphia",
    "meetupURL": "Philadelphia-Amazon-Alexa-Meetup",
  },
  {
    "city": "Pittsburgh",
    "meetupURL": "Pittsburgh-Amazon-Alexa-Meetup",
  },
  {
    "city": "San Francisco",
    "meetupURL": "SF-Amazon-Alexa",
  }
];

module.exports = alexaMeetups;
